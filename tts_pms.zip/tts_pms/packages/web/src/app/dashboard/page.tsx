'use client';

import React from 'react';
import { ResponsiveDashboard } from '../../components/dashboard/responsive-dashboard';

export default function DashboardPage() {
  return <ResponsiveDashboard />;
}
