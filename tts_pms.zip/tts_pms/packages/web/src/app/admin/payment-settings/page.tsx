'use client';

import React from 'react';
import { PaymentSettings } from '../../../components/admin/payment-settings';

export default function PaymentSettingsPage() {
  return <PaymentSettings />;
}
