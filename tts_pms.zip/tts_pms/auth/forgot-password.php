<?php
/**
 * TTS PMS - Forgot Password (Alternative Path)
 * Password reset functionality - Alternative auth directory
 */

// Redirect to the main forgot password page
header('Location: ../packages/web/auth/forgot-password.php');
exit;
?>
